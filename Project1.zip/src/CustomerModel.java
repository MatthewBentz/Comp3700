public class CustomerModel {
    public int customerID;
    public String customerName;
    public String address;
}
