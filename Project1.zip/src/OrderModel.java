public class OrderModel {
    public int orderID;
    public String orderDate;
    public String customerName;
    public double totalCost;
    public double totalTax;
}
