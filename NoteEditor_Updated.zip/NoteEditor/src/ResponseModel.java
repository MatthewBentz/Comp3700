public class ResponseModel {

    static public int OK = 0;
    static public int UNKNOWN_REQUEST = 1;
    static public int DATA_NOT_FOUND = 2;


    public int code;
    public String body;
}

